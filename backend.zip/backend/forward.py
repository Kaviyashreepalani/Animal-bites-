import firebase_admin
from firebase_admin import credentials, firestore
from datetime import datetime
import os, json
import dotenv
from typing import Optional, List, Dict, Any
from typing import List, Dict, Any
import logging
from pymongo import MongoClient
from typing import List, Dict, Any
import os
from datetime import datetime
from flask import session
from bson import ObjectId

dotenv.load_dotenv()

# -------- Firebase init (env JSON) --------
def get_firebase_config():
    firebase_key = os.environ.get("FIREBASE_SERVICE_ACCOUNT_KEY")
    if firebase_key:
        if firebase_key.strip().startswith('{'):
            return json.loads(firebase_key)
        raise ValueError("FIREBASE_SERVICE_ACCOUNT_KEY must be a JSON string in .env")
    raise ValueError("FIREBASE_SERVICE_ACCOUNT_KEY not found in environment variables.")

def initialize_firebase():
    if firebase_admin._apps:
        return firestore.client()
    firebase_config = get_firebase_config()
    cred = credentials.Certificate(firebase_config)
    firebase_admin.initialize_app(cred)
    return firestore.client()

db = initialize_firebase()

# Helper function to check if a conversation is casual
def is_casual_conversation(question, answer):
    """Check if a conversation is casual/unnecessary"""
    casual_patterns = [
        "hi", "hello", "hey", "good morning", "good afternoon", "good evening",
        "how are you", "thank you", "thanks", "bye", "goodbye", "ok", "okay",
        "yes", "no", "sure", "great", "awesome", "cool", "nice", "fine",
        "what's up", "how's it going", "see you", "take care", "good night",
        "good day", "how do you do", "pleased to meet you", "nice to meet you"
    ]
    
    question_lower = question.lower().strip()
    if any(pattern in question_lower for pattern in casual_patterns):
        return True
    
    if len(question.strip()) < 10:
        return True
    
    answer_lower = answer.lower().strip()
    greeting_responses = [
        "hello", "hi there", "good morning", "good afternoon", "good evening",
        "how can i help", "nice to meet you", "pleased to meet you",
        "thank you for", "you're welcome", "no problem"
    ]
    
    if any(response in answer_lower for response in greeting_responses):
        return True
    
    if len(answer.strip()) < 20:
        return True
    
    return False

# Helper function to check for duplicate questions
def is_duplicate_question(question, existing_questions):
    """Check if a question is a duplicate or very similar to existing ones"""
    question_lower = question.lower().strip()
    
    for existing in existing_questions:
        existing_lower = existing.lower().strip()
        # Simple similarity check - can be enhanced with more sophisticated methods
        if question_lower == existing_lower:
            return True
        # Check if one question contains most words of another (simple similarity)
        q_words = set(question_lower.split())
        e_words = set(existing_lower.split())
        if len(q_words) > 3 and len(e_words) > 3:
            intersection = q_words.intersection(e_words)
            if len(intersection) >= min(len(q_words), len(e_words)) * 0.7:
                return True
    return False

# -------- Existing helpers you already had --------
def save_unanswered_question(question_english: str):
    """Save unanswered question with timestamp"""
    # Don't save casual conversations
    if is_casual_conversation(question_english, ""):
        print(f"DEBUG: Skipping casual question: {question_english}")
        return
    
    doctor_doc_ref = db.collection("DOCTOR").document("1")
    doc = doctor_doc_ref.get()
    data = doc.to_dict() if doc.exists else {}
    
    # Store questions as objects with timestamps
    qn_list = data.get("qn", []) or []
    
    # Get existing questions for duplicate check
    existing_questions = []
    for q in qn_list:
        if isinstance(q, dict):
            existing_questions.append(q.get("question", ""))
        else:
            existing_questions.append(q)
    
    # Check if question is a duplicate
    if is_duplicate_question(question_english, existing_questions):
        print(f"DEBUG: Skipping duplicate question: {question_english}")
        return
    
    question_obj = {
        "question": question_english,
        "timestamp": datetime.now(),
        "status": "pending"
    }
    qn_list.append(question_obj)
    doctor_doc_ref.set({"qn": qn_list}, merge=True)
    print(f"DEBUG: Saved unanswered question: {question_english}")

def save_user_interaction(question_english: str, answer_english: str, user_session_id: Optional[str] = None):
    """Save user interaction and filter out casual conversations"""
    
    # Don't save casual conversations
    if is_casual_conversation(question_english, answer_english):
        print(f"DEBUG: Skipping casual conversation: {question_english}")
        return
    
    # Don't save fallback responses
    fallback_responses = [
        "Sorry, but I specialize in answering questions related to animal bites",
        "I am unable to answer your question at the moment. The Doctor has been notified",
        "An internal error occurred"
    ]
    
    if any(fallback in answer_english for fallback in fallback_responses):
        print(f"DEBUG: Skipping fallback response: {question_english}")
        return
    
    interaction_data = {
        "question": question_english,
        "answer": answer_english,
        "timestamp": datetime.now(),
        "session_id": user_session_id or "anonymous",
        "status": "answered"
    }
    
    unanswered_indicators = [
        "doctor has been notified",
        "doctor will be notified", 
        "check back in a few days",
        "unable to answer your question"
    ]
    
    # Check if this interaction was forwarded to doctor
    if any(indicator in answer_english.lower() for indicator in unanswered_indicators):
        interaction_data["status"] = "forwarded_to_doctor"
        
        # IMPORTANT: Also save this as an unanswered question
        # This ensures forwarded questions appear in both sections
        try:
            save_unanswered_question(question_english)
            print(f"DEBUG: Question forwarded to doctor also saved as unanswered: {question_english}")
        except Exception as e:
            print(f"ERROR: Failed to save forwarded question as unanswered: {e}")
    
    db.collection("user").add(interaction_data)
    print(f"DEBUG: Saved user interaction: {question_english}")

# -------- New helpers for dashboard --------


def get_unanswered_questions() -> List[Dict[str, Any]]:
    """
    Get unanswered questions with timestamps (excluding casual ones).
    
    Returns:
        List[Dict[str, Any]]: List of dictionaries containing unanswered questions
            Each dictionary contains:
                - question: str - The text of the question
                - timestamp: datetime - When the question was asked
                - status: str - Current status of the question
                - forwarded_from: Optional[str] - ID of doctor who forwarded the question
    """
    try:
        doc = db.collection("DOCTOR").document("1").get()
        if doc.exists:
            data = doc.to_dict()
            qn_list = data.get("qn", []) or []
            ans_dict = data.get("ans", {}) or {}
            
            unanswered = []
            
            def process_question(q_data):
                """Helper function to process a single question"""
                question_text = q_data.get("question", "")
                status = q_data.get("status", "pending")
                
                # Skip empty questions
                if not question_text:
                    return False
                
                # Check if question exists in answers dictionary
                is_answered = question_text in ans_dict
                
                # Get forwarding information
                forwarded_from = None
                if "forwarded_by" in q_data:
                    forwarded_from = q_data["forwarded_by"]
                
                # Determine if question is unanswered
                # Include questions forwarded to doctor regardless of status
                is_unanswered = (
                    status == "pending" 
                    and not is_answered
                    and not is_casual_conversation(question_text, forwarded_from or "")
                ) or (
                    "forwarded_by" in q_data  # Include forwarded questions
                )
                
                if is_unanswered:
                    unanswered.append({
                        "question": question_text,
                        "timestamp": q_data.get("timestamp"),
                        "status": status,
                        "forwarded_from": forwarded_from
                    })
                return is_unanswered

            # Process all questions
            for q in qn_list:
                if isinstance(q, dict):
                    process_question(q)
                else:
                    # Handle old format (string questions)
                    if q and q not in ans_dict and not is_casual_conversation(q, ""):
                        unanswered.append({
                            "question": q,
                            "timestamp": None,
                            "status": "pending",
                            "forwarded_from": None
                        })

            logging.debug(f"Found {len(unanswered)} unanswered questions")
            return unanswered
        
    except Exception as e:
        logging.error(f"Failed to get unanswered questions: {str(e)}")
        return []
    
def submit_answer(question: str, answer: str) -> None:
    """Submit answer and update question status"""
    try:
        # Update DOCTOR document with answer
        doctor_ref = db.collection("DOCTOR").document("1")
        doc = doctor_ref.get()
        data = doc.to_dict() if doc.exists else {}
        
        # Add to answers
        ans_dict = data.get("ans", {}) or {}
        ans_dict[question] = answer
        
        # Update question status to answered
        qn_list = data.get("qn", []) or []
        updated_qn_list = []
        
        for q in qn_list:
            if isinstance(q, dict):
                if q.get("question") == question:
                    q["status"] = "answered"
                    q["answered_at"] = datetime.now()
                updated_qn_list.append(q)
            else:
                # Handle old format
                if q == question:
                    updated_qn_list.append({
                        "question": q,
                        "timestamp": datetime.now(),
                        "status": "answered",
                        "answered_at": datetime.now()
                    })
                else:
                    updated_qn_list.append(q)
        
        # Update document
        doctor_ref.set({
            "ans": ans_dict,
            "qn": updated_qn_list
        }, merge=True)

        # Store in solved questions collection
        solved_qa_data = {
            "question": question,
            "answer": answer,
            "timestamp": datetime.now(),
            "source": "dashboard_submit",
            "status": "active"
        }
        db.collection("solved_questions").add(solved_qa_data)

        # Store in MongoDB for retrieval
        try:
            from embedding import store_question_answer
            store_question_answer(question, answer)
            print(f"DEBUG: Successfully stored Q&A in MongoDB: {question}")
        except Exception as e:
            print(f"ERROR: Failed to store in MongoDB: {e}")

        # Save interaction record
        db.collection("user").add({
            "question": question,
            "answer": answer,
            "timestamp": datetime.now(),
            "session_id": "dashboard",
            "status": "answered_by_doctor"
        })
        
        print(f"DEBUG: Answer submitted successfully for question: {question}")
        
    except Exception as e:
        print(f"ERROR: Failed to submit answer: {e}")
        raise

def get_user_queries(limit: int = 100) -> List[Dict[str, Any]]:
    """Get user queries excluding casual conversations"""
    try:
        q = db.collection("user").order_by("timestamp", direction=firestore.Query.DESCENDING).limit(limit)
        rows = []
        for doc in q.stream():
            d = doc.to_dict()
            question = d.get("question", "")
            answer = d.get("answer", "")
            
            # Filter out casual conversations
            if not is_casual_conversation(question, answer):
                ts = d.get("timestamp")
                d["id"] = doc.id
                d["timestamp"] = ts.isoformat() if hasattr(ts, "isoformat") else str(ts)
                rows.append(d)
        
        print(f"DEBUG: Found {len(rows)} user queries")
        return rows
        
    except Exception as e:
        print(f"ERROR: Failed to get user queries: {e}")
        return []

def get_daily_stats() -> Dict[str, int]:
    """Get statistics for today"""
    try:
        today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        
        # Count resolved questions today
        resolved_today = 0
        try:
            query = db.collection("solved_questions").where("timestamp", ">=", today).where("status", "==", "active")
            resolved_today = len(list(query.stream()))
        except Exception as e:
            print(f"DEBUG: Error getting daily stats: {e}")
        
        # Get total queries and pending questions
        total_queries = len(get_user_queries(500))
        pending_questions = len(get_unanswered_questions())
        
        stats = {
            "resolved_today": resolved_today,
            "total_queries": total_queries,
            "pending_questions": pending_questions
        }
        
        print(f"DEBUG: Stats - {stats}")
        return stats
        
    except Exception as e:
        print(f"ERROR: Failed to get daily stats: {e}")
        return {"resolved_today": 0, "total_queries": 0, "pending_questions": 0}

def add_question_answer(question: str, answer: str) -> None:
    """Add new Q&A pair"""
    try:
        # Store in MongoDB
        try:
            from embedding import store_question_answer
            store_question_answer(question, answer)
            print(f"DEBUG: Successfully stored new Q&A in MongoDB: {question}")
        except Exception as e:
            print(f"ERROR: Failed to store in MongoDB: {e}")
        
        # Update DOCTOR document
        doctor_ref = db.collection("DOCTOR").document("1")
        doc = doctor_ref.get()
        data = doc.to_dict() if doc.exists else {}
        ans_dict = data.get("ans", {}) or {}
        ans_dict[question] = answer
        doctor_ref.set({"ans": ans_dict}, merge=True)
        
        # Store in solved questions collection
        solved_qa_data = {
            "question": question,
            "answer": answer,
            "timestamp": datetime.now(),
            "source": "dashboard_manual",
            "status": "active"
        }
        db.collection("solved_questions").add(solved_qa_data)
        
        # Save interaction record
        db.collection("user").add({
            "question": question,
            "answer": answer,
            "timestamp": datetime.now(),
            "session_id": "dashboard_manual",
            "status": "answered_by_doctor"
        })
        
        print(f"DEBUG: Successfully added new Q&A: {question}")
        
    except Exception as e:
        print(f"ERROR: Failed to add Q&A: {e}")
        raise

# -------- New functions for Questions Solved section --------
def get_solved_questions(limit: int = 50) -> List[Dict[str, Any]]:
    """Get all solved questions with edit/delete capability"""
    try:
        q = db.collection("solved_questions").where("status", "==", "active").order_by("timestamp", direction=firestore.Query.DESCENDING).limit(limit)
        rows = []
        for doc in q.stream():
            d = doc.to_dict()
            ts = d.get("timestamp")
            d["id"] = doc.id
            d["timestamp"] = ts.isoformat() if hasattr(ts, "isoformat") else str(ts)
            rows.append(d)
        
        print(f"DEBUG: Found {len(rows)} solved questions")
        return rows
        
    except Exception as e:
        print(f"ERROR: Failed to get solved questions: {e}")
        return []

def update_solved_question(doc_id: str, question: str, answer: str) -> None:
    """Update a solved question"""
    try:
        # Get the old question first
        solved_doc = db.collection("solved_questions").document(doc_id).get()
        if not solved_doc.exists:
            raise ValueError("Question not found")
        
        old_data = solved_doc.to_dict()
        old_question = old_data.get("question", "")
        
        # Update solved_questions collection
        db.collection("solved_questions").document(doc_id).update({
            "question": question,
            "answer": answer,
            "updated_at": datetime.now()
        })
        
        # Update DOCTOR document - remove old answer and add new one
        doctor_ref = db.collection("DOCTOR").document("1")
        doc = doctor_ref.get()
        data = doc.to_dict() if doc.exists else {}
        ans_dict = data.get("ans", {}) or {}
        
        # Remove old answer if question changed
        if old_question in ans_dict and old_question != question:
            del ans_dict[old_question]
        
        # Add new answer
        ans_dict[question] = answer
        doctor_ref.set({"ans": ans_dict}, merge=True)
        
        # Update MongoDB
        try:
            from embedding import update_question_answer
            update_question_answer(old_question, question, answer)
            print(f"DEBUG: Successfully updated Q&A in MongoDB: {question}")
        except Exception as e:
            print(f"ERROR: Failed to update in MongoDB: {e}")
        
        print(f"DEBUG: Successfully updated solved question: {question}")
        
    except Exception as e:
        print(f"ERROR: Failed to update solved question: {e}")
        raise

def delete_solved_question(doc_id: str) -> None:
    """Delete a solved question"""
    try:
        # Get the question first
        solved_doc = db.collection("solved_questions").document(doc_id).get()
        if not solved_doc.exists:
            raise ValueError("Question not found")
        
        question_data = solved_doc.to_dict()
        question = question_data.get("question", "")
        
        # Mark as deleted in solved_questions collection
        db.collection("solved_questions").document(doc_id).update({
            "status": "deleted",
            "deleted_at": datetime.now()
        })
        
        # Remove from DOCTOR document
        doctor_ref = db.collection("DOCTOR").document("1")
        doc = doctor_ref.get()
        data = doc.to_dict() if doc.exists else {}
        ans_dict = data.get("ans", {}) or {}
        
        if question in ans_dict:
            del ans_dict[question]
            doctor_ref.set({"ans": ans_dict}, merge=True)
        
        # Remove from MongoDB
        try:
            from embedding import delete_question_answer
            delete_question_answer(question)
            print(f"DEBUG: Successfully deleted Q&A from MongoDB: {question}")
        except Exception as e:
            print(f"ERROR: Failed to delete from MongoDB: {e}")
        
        print(f"DEBUG: Successfully deleted solved question: {question}")
        
    except Exception as e:
        print(f"ERROR: Failed to delete solved question: {e}")
        raise